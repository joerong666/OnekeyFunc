from func.overlord import overlord_module

class test(overlord_module.BaseModule):
    def return1(self):
        return 1
